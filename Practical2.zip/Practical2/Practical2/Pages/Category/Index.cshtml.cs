using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Practical2.Data;

namespace Practical2.Pages.Category
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        public IndexModel(ApplicationDbContext db)
        {
            _db = db;
        }
        public IEnumerable<Models.Category> Categories { get; set; }
        public void OnGet(string? prodname)
        {
            if (_db.Categories != null)
            {
                if(prodname != null)
                {

                }
                Categories = _db.Categories;
                
            }
        }
    }
}

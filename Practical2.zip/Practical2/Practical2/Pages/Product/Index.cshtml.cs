﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Practical2.Data;
using Practical2.Models;

namespace Practical2
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Product> Product { get;set; }

        public void OnGet()
        {
            if (_context.Products != null)
            {
                Product = _context.Products
                .Include(p => p.Category).ToList();
            }
        }
    }
}
